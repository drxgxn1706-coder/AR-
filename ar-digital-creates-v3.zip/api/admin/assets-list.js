import { db } from "hatchable";
export const access = "admin";
export const methods = ["GET"];
export default async function(req,res){const {rows}=await db.query("SELECT id,kind,label,url,created_at FROM assets ORDER BY created_at DESC");res.json(rows);}